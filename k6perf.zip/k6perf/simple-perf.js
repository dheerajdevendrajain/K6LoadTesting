import http from 'k6/http';
import { check, sleep } from 'k6';
import { Counter, Trend } from 'k6/metrics';

// Custom Metrics

const apiResponseTime = new Trend('api_response_time');          // Total request+response time
const serverProcessingTime = new Trend('server_processing_time'); // Server processing only (waiting)
const responseDownloadTime = new Trend('response_download_time'); // Response download time
const successfulRequests = new Counter('successful_requests');    // Count successful requests

// Configuration: Stages and Thresholds
export const options = {
  // Stages: Define how many virtual users (VUs) to run over time
  stages: [
    { duration: '4s', target: 2 },   // Ramp up to 2 VUs over 4 seconds
    { duration: '5s', target: 5 },   // Stay at 5 VUs for 5 seconds
    { duration: '2s', target: 0 },   // Ramp down to 0 VUs over 2 seconds
  ],
  
  // Thresholds: Pass/fail criteria for your test
  thresholds: {
    'http_req_duration': ['p(95)<500'],  // 95% of requests should be faster than 500ms
    'http_req_failed': ['rate<0.1'],     // Less than 10% of requests should fail
    'checks': ['rate>0.9'],              // More than 90% of checks should pass
    'http_req_duration{name:api}': ['p(95)<400'],
  },
 };

// Main test function - runs for each virtual user
export default function () {
  // Make a simple HTTP GET requestk6
  const response = http.get('https://quickpizza.grafana.com/');
  
  // Check if the response is what we expect
  const checkResults = check(response, {
    'status is 200': (r) => r.status === 200,
    'page contains k6.io': (r) => r.body.includes('pizza'),
  });

   http.get('https://quickpizza.grafana.com/api/pizza', {
    tags: { name: 'api' }
  });
  
  // Record different timing metrics
  apiResponseTime.add(response.timings.duration);        // Total time (request + response)
  serverProcessingTime.add(response.timings.waiting);    // Server processing time only
  responseDownloadTime.add(response.timings.receiving);  // Response download time only
  
  // Count successful requests (when all checks pass)
  if (checkResults) {
    successfulRequests.add(1);
  }
  
  // Wait 1 second before next iteration (simulates user think time)
  sleep(1);
}
