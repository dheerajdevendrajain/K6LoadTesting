import http from 'k6/http';
import { check, group, sleep } from 'k6';
import { Counter, Trend, Rate } from 'k6/metrics';
import exec from 'k6/execution';

// 1. Custom Metrics
// Define custom metrics to track specific aspects of your test.
const successfulLoginCounter = new Counter('successful_logins');
const apiResponseTimeTrend = new Trend('api_response_time');
const errorRate = new Rate('error_rate');

// 2. Options: Stages (Ramp-up), Thresholds, and Test-wide Tags
export const options = {
  // Test-wide tags (applied to all metrics by default)
  tags: {
    test_type: 'load_test',
    environment: 'staging',
  },
  // Stages for ramp-up, steady load, and ramp-down
  stages: [
    { duration: '30s', target: 10, tags: { stage: 'ramp_up' } },   // Ramp-up to 10 VUs in 30 seconds
    { duration: '1m', target: 20, tags: { stage: 'steady_load_1' } }, // Stay at 20 VUs for 1 minute
    { duration: '30s', target: 20, tags: { stage: 'steady_load_2' } }, // Stay at 20 VUs for 30 seconds (another segment)
    { duration: '30s', target: 5, tags: { stage: 'ramp_down' } },   // Ramp-down to 5 VUs in 30 seconds
    { duration: '10s', target: 0, tags: { stage: 'teardown' } },  // Ramp-down to 0 VUs in 10 seconds
  ],
  // Thresholds for pass/fail criteria
  thresholds: {
    'http_req_duration{name:Homepage}': ['p(95)<200', 'p(99)<400'], // 95th percentile response time < 200ms, 99th < 400ms for Homepage
    'http_req_duration{name:ProductPage}': ['avg<150'],           // Average response time < 150ms for Product Page
    'checks': ['rate>0.99'],                                    // 99% of checks must pass
    'successful_logins': ['count>50'],                          // At least 50 successful logins
    'error_rate': ['rate<0.01'],                                // Error rate less than 1%
  },
  // Global discardResponseBodies (for performance, if you don't need the response body)
  discardResponseBodies: true,
};

// 3. Lifecycle Methods

// init stage: This code runs once per VU, before any VUs start executing the default function.
// Use this for global setup that doesn't need to be run per iteration.
export function setup() {
  console.log('Setup stage: Initializing test data or environment (runs once before VUs start)');
  // Example: Login once and reuse a token for all VUs (though for real load tests,
  // typically each VU would have its own unique user/token).
  const loginRes = http.post('https://test-api.k6.io/auth/token/login/', JSON.stringify({
    username: 'user',
    password: 'password'
  }), {
    tags: { name: 'Login' }
  });

  check(loginRes, {
    'login status is 200': (r) => r.status === 200,
  });

  if (loginRes.status === 200) {
    console.log('Login successful in setup!');
    return { authToken: loginRes.json('access') }; // Return data that can be used in the default function
  } else {
    console.error('Login failed in setup:', loginRes.body);
    return { authToken: null };
  }
}

// default function (VU stage): This is where the actual load generation logic resides.
// It runs repeatedly for each virtual user during the test duration.
export default function (data) {
  // Access data returned from the setup function
  const authToken = data ? data.authToken : null;

  // Tag the current VU's scenario (useful if you have multiple scenarios)
  exec.vu.tags.scenario = 'user_journey';

  // Group requests for better organization and metric aggregation
  group('User Flow: Browse and Product View', function () {
    // 4. HTTP Request with Tags and Checks
    const homepageRes = http.get('https://test.k6.io/', {
      tags: { name: 'Homepage', custom_tag: 'initial_page' }, // User-defined tags for this specific request
    });

    // Checks: Verify response integrity
    check(homepageRes, {
      'Homepage: status is 200': (r) => r.status === 200,
      'Homepage: contains "k6.io"': (r) => r.body.includes('k6.io'),
    }, { check_tag: 'homepage_checks' }); // Tags for checks

    // Add data to custom metrics
    apiResponseTimeTrend.add(homepageRes.timings.duration, { page: 'homepage' });
    if (homepageRes.status !== 200) {
      errorRate.add(1);
    } else {
      errorRate.add(0);
    }

    sleep(1); // Simulate user think time

    const productPageRes = http.get('https://test.k6.io/contacts.php', {
      tags: { name: 'ProductPage', category: 'information' },
    });

    check(productPageRes, {
      'ProductPage: status is 200': (r) => r.status === 200,
      'ProductPage: contains "Contact Us"': (r) => r.body.includes('Contact Us'),
    }, { check_tag: 'product_page_checks' });

    apiResponseTimeTrend.add(productPageRes.timings.duration, { page: 'productpage' });
    if (productPageRes.status !== 200) {
      errorRate.add(1);
    } else {
      errorRate.add(0);
    }

    sleep(Math.random() * 2); // Random sleep between 0 and 2 seconds
  });

  group('User Flow: Login Attempt', function () {
    const loginAttemptRes = http.post('https://test-api.k6.io/auth/token/login/', JSON.stringify({
      username: 'testuser',
      password: 'wrongpassword' // Simulate a failed login
    }), {
      headers: { 'Content-Type': 'application/json' },
      tags: { name: 'LoginAPI', flow: 'authentication' },
    });

    check(loginAttemptRes, {
      'LoginAPI: status is 400 (expected for wrong credentials)': (r) => r.status === 400,
    });

    // If it was a successful login (e.g., if you changed the password to a correct one)
    if (loginAttemptRes.status === 200) {
      successfulLoginCounter.add(1);
    }
  });

  // Example of using the authToken if it was successfully obtained in setup
  if (authToken) {
    const protectedResourceRes = http.get('https://test-api.k6.io/user/me/', {
      headers: {
        'Authorization': `Bearer ${authToken}`,
      },
      tags: { name: 'ProtectedResource', auth_status: 'authenticated' },
    });

    check(protectedResourceRes, {
      'ProtectedResource: status is 200': (r) => r.status === 200,
      'ProtectedResource: contains "email"': (r) => r.body.includes('email'),
    });
  } else {
    console.warn('Skipping protected resource test: No authentication token available.');
  }

  sleep(1); // Sleep to simulate user behavior and prevent overwhelming the server
}

// teardown stage: This code runs once after all VUs have finished executing.
// Use this for global cleanup, like deleting test data or closing connections.
export function teardown(data) {
  console.log('Teardown stage: Cleaning up test environment (runs once after all VUs finish)');
  console.log('Data from setup:', data);

  // Example: Log out or delete user created during the test
  if (data && data.authToken) {
    console.log('Performing logout...');
    const logoutRes = http.post('https://test-api.k6.io/auth/token/logout/', null, {
      headers: {
        'Authorization': `Bearer ${data.authToken}`,
      },
      tags: { name: 'Logout' }
    });
    check(logoutRes, {
      'logout status is 204': (r) => r.status === 204,
    });
    if (logoutRes.status === 204) {
      console.log('Logout successful in teardown!');
    } else {
      console.error('Logout failed in teardown:', logoutRes.body);
    }
  }
}