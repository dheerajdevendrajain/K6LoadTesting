import http from 'k6/http';
import { check, sleep } from 'k6';

// Configuration: Simple stages for demonstration
export const options = {
  stages: [
    { duration: '10s', target: 2 },   // Ramp up to 2 VUs over 10 seconds
    { duration: '20s', target: 3 },   // Stay at 3 VUs for 20 seconds
    { duration: '10s', target: 0 },   // Ramp down to 0 VUs over 10 seconds
  ],
  
  // Thresholds: Notice how we can set different thresholds for different tagged requests
  thresholds: {
    'http_req_duration': ['p(95)<500'],                    // All requests combined
    'http_req_duration{name:homepage}': ['p(95)<300'],     // Only homepage requests
    'http_req_duration{name:contact}': ['p(95)<400'],      // Only contact page requests
    'http_req_duration{name:about}': ['p(95)<350'],        // Only about page requests
    'http_req_failed': ['rate<0.1'],
    'checks': ['rate>0.9'],
  },
};

// Main test function - runs for each virtual user
export default function () {
  // Request 1: Homepage with tag
  const homepageResponse = http.get('https://test.k6.io/', {
    tags: { name: 'homepage' }  // Tag this request as 'homepage'
  });
  
  check(homepageResponse, {
    'homepage status is 200': (r) => r.status === 200,
    'homepage contains k6.io': (r) => r.body.includes('k6.io'),
  });
  
  sleep(1); // Simulate user think time
  
  // Request 2: Contact page with tag
  const contactResponse = http.get('https://test.k6.io/contacts.php', {
    tags: { name: 'contact' }   // Tag this request as 'contact'
  });
  
  check(contactResponse, {
    'contact status is 200': (r) => r.status === 200,
    'contact contains Contact': (r) => r.body.includes('Contact'),
  });
  
  sleep(1); // Simulate user think time
  
  // Request 3: About page with tag
  const aboutResponse = http.get('https://test.k6.io/my_messages.php', {
    tags: { name: 'about' }     // Tag this request as 'about'
  });
  
  check(aboutResponse, {
    'about status is 200': (r) => r.status === 200,
  });
  
  sleep(1); // Simulate user think time between iterations
}
