import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Counter, Trend, Rate, Gauge } from 'k6/metrics';

// Custom Metrics - All four types for comprehensive monitoring
const transactionTime = new Trend('transaction_time');           // Track end-to-end transaction timing
const successfulOrders = new Counter('successful_orders');       // Count completed order flows
const authenticationRate = new Rate('authentication_rate');      // Track login success rate
const activeUsers = new Gauge('active_users');                   // Track concurrent authenticated users

// Utility function to generate random strings
function randomString(length, charset = '') {
  if (!charset) charset = 'abcdefghijklmnopqrstuvwxyz';
  let res = '';
  while (length--) res += charset[(Math.random() * charset.length) | 0];
  return res;
}

// Generate unique user for each VU iteration
const USERNAME = `user_${randomString(8)}@ecommerce.test`;
const PASSWORD = 'securepassword123';
const BASE_URL = 'https://quickpizza.grafana.com';

// Configuration: Advanced load testing with multiple stages
export const options = {
  stages: [
    { duration: '30s', target: 5 },   // Warm-up: 5 users
    { duration: '1m', target: 10 },   // Ramp up: 10 users
    { duration: '2m', target: 15 },   // Peak load: 15 users
    { duration: '1m', target: 10 },   // Scale down: 10 users  
    { duration: '30s', target: 0 },   // Cool down: 0 users
  ],
  
  // Comprehensive thresholds: Built-in + Tagged + Groups + Custom metrics
  thresholds: {
    // Overall performance thresholds
    'http_req_duration': ['p(95)<2000'],                           // Overall 95th percentile < 2s
    'http_req_failed': ['rate<0.05'],                              // Less than 5% failures
    'checks': ['rate>0.95'],                                       // More than 95% checks pass
    'iteration_duration': ['p(95)<30000'],                         // Complete user journey < 30s
    
    // Tagged thresholds - Per-endpoint performance
    'http_req_duration{name:register}': ['p(95)<1000'],           // User registration < 1s
    'http_req_duration{name:login}': ['p(95)<800'],               // Login authentication < 800ms
    'http_req_duration{name:create_order}': ['p(95)<1500'],       // Order creation < 1.5s
    'http_req_duration{name:get_order}': ['p(95)<500'],           // Order retrieval < 500ms
    'http_req_duration{name:list_orders}': ['p(95)<1000'],        // List orders < 1s
    'http_req_duration{name:delete_order}': ['p(95)<800'],        // Order deletion < 800ms
    
    // Group thresholds - Per-workflow performance
    'group_duration{group:::User Registration}': ['avg<1500'],     // Registration workflow < 1.5s
    'group_duration{group:::Authentication}': ['avg<1000'],        // Auth workflow < 1s
    'group_duration{group:::Order Management}': ['avg<3000'],      // Order workflow < 3s
    'group_duration{group:::Order Verification}': ['avg<1000'],    // Verification workflow < 1s
    'group_duration{group:::Cleanup}': ['avg<800'],               // Cleanup workflow < 800ms
    
    // Group-specific check rates
    'checks{group:::User Registration}': ['rate>0.98'],           // Registration checks > 98%
    'checks{group:::Authentication}': ['rate>0.99'],              // Auth checks > 99%
    'checks{group:::Order Management}': ['rate>0.95'],            // Order checks > 95%
    'checks{group:::Order Verification}': ['rate>0.98'],          // Verification checks > 98%
    'checks{group:::Cleanup}': ['rate>0.90'],                     // Cleanup checks > 90%
    
    // Custom metrics thresholds - Business logic
    'transaction_time': ['p(95)<25000'],                           // End-to-end transaction < 25s
    'successful_orders': ['count>20'],                            // At least 20 successful orders
    'authentication_rate': ['rate>0.98'],                         // 98%+ authentication success
    'active_users': ['value>=0'],                                 // Monitor active user gauge
  },
};

// Setup function: Runs once before all VUs start
export function setup() {
  console.log('🚀 Starting E-commerce Performance Test Setup...');
  
  // Setup can be used for global initialization, data preparation, etc.
  return {
    testStartTime: new Date().toISOString(),
    baseUrl: BASE_URL
  };
}

// Main test function - Complete E-commerce User Journey
export default function (data) {
  const transactionStart = new Date();
  let authToken = null;
  let orderId = null;
  let userRegistered = false;
  let userAuthenticated = false;
  let orderCreated = false;
  
  // Update active users gauge
  activeUsers.add(1);
  
  // Group 1: User Registration - Create a new user account
  group('User Registration', function () {
    const registerPayload = {
      username: USERNAME,
      password: PASSWORD
    };
    
    const registerResponse = http.post(
      `${BASE_URL}/api/users`,
      JSON.stringify(registerPayload),
      {
        headers: { 'Content-Type': 'application/json' },
        tags: { name: 'register', flow: 'registration', operation: 'POST' }
      }
    );
    
    userRegistered = check(registerResponse, {
      'user registration status is 201': (r) => r.status === 201,
      'user registration response is valid JSON': (r) => {
        try {
          r.json();
          return true;
        } catch {
          return false;
        }
      },
      'user registration contains user data': (r) => r.json('id') !== undefined,
    });
    
    if (!userRegistered) {
      console.error(`❌ User registration failed: ${registerResponse.status} - ${registerResponse.body}`);
      authenticationRate.add(0);
      return; // Exit early if registration fails
    }
    
    console.log(`✅ User registered successfully: ${USERNAME}`);
  });
  
  sleep(1); // Simulate user thinking time
  
  // Group 2: Authentication - Login and get bearer token
  group('Authentication', function () {
    const loginPayload = {
      username: USERNAME,
      password: PASSWORD
    };
    
    const loginResponse = http.post(
      `${BASE_URL}/api/users/token/login`,
      JSON.stringify(loginPayload),
      {
        headers: { 'Content-Type': 'application/json' },
        tags: { name: 'login', flow: 'authentication', operation: 'POST' }
      }
    );
    
    userAuthenticated = check(loginResponse, {
      'login status is 200': (r) => r.status === 200,
      'login response contains token': (r) => r.json('token') !== undefined,
      'token is valid string': (r) => typeof r.json('token') === 'string' && r.json('token').length > 0,
    });
    
    if (userAuthenticated) {
      authToken = loginResponse.json('token');
      authenticationRate.add(1); // Record successful authentication
      console.log(`🔐 User authenticated successfully: ${USERNAME}`);
    } else {
      authenticationRate.add(0); // Record failed authentication
      console.error(`❌ Authentication failed: ${loginResponse.status} - ${loginResponse.body}`);
      return; // Exit early if authentication fails
    }
  });
  
  sleep(1); // Simulate user navigation time
  
  // Group 3: Order Management - Create, Read, Update operations
  group('Order Management', function () {
    // Headers for authenticated requests
    const authHeaders = {
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    };
    
    // Step 1: Create a new order (POST)
    const orderPayload = {
      pizza_id: Math.floor(Math.random() * 5) + 1, // Random pizza ID (1-5)
      stars: Math.floor(Math.random() * 5) + 1,    // Random rating (1-5 stars)
      comment: `Order from automated test user ${USERNAME.split('@')[0]}`
    };
    
    const createOrderResponse = http.post(
      `${BASE_URL}/api/ratings`,
      JSON.stringify(orderPayload),
      {
        ...authHeaders,
        tags: { name: 'create_order', flow: 'order_management', operation: 'POST' }
      }
    );
    
    orderCreated = check(createOrderResponse, {
      'order creation status is 201': (r) => r.status === 201,
      'order creation response contains ID': (r) => r.json('id') !== undefined,
      'order creation stars match': (r) => r.json('stars') === orderPayload.stars,
      'order creation pizza_id match': (r) => r.json('pizza_id') === orderPayload.pizza_id,
    });
    
    if (orderCreated) {
      orderId = createOrderResponse.json('id');
      console.log(`📦 Order created successfully: ${orderId}`);
    } else {
      console.error(`❌ Order creation failed: ${createOrderResponse.status} - ${createOrderResponse.body}`);
      return; // Exit early if order creation fails
    }
    
    sleep(0.5); // Brief pause between operations
    
    // Step 2: Retrieve the specific order (GET)
    const getOrderResponse = http.get(
      `${BASE_URL}/api/ratings/${orderId}`,
      {
        ...authHeaders,
        tags: { name: 'get_order', flow: 'order_management', operation: 'GET' }
      }
    );
    
    const orderRetrieved = check(getOrderResponse, {
      'order retrieval status is 200': (r) => r.status === 200,
      'retrieved order ID matches': (r) => r.json('id') === orderId,
      'retrieved order has correct stars': (r) => r.json('stars') === orderPayload.stars,
      'retrieved order has correct pizza_id': (r) => r.json('pizza_id') === orderPayload.pizza_id,
    });
    
    if (orderRetrieved) {
      console.log(`✅ Order retrieved successfully: ${orderId}`);
    }
    
    sleep(0.5); // Brief pause between operations
    
    // Step 3: List all user orders (GET)
    const listOrdersResponse = http.get(
      `${BASE_URL}/api/ratings`,
      {
        ...authHeaders,
        tags: { name: 'list_orders', flow: 'order_management', operation: 'GET' }
      }
    );
    
    const ordersListed = check(listOrdersResponse, {
      'orders list status is 200': (r) => r.status === 200,
      'orders list contains ratings array': (r) => Array.isArray(r.json('ratings')),
      'orders list is not empty': (r) => r.json('ratings').length > 0,
      'orders list contains our order': (r) => {
        const ratings = r.json('ratings');
        return ratings.some(rating => rating.id === orderId);
      },
    });
    
    if (ordersListed) {
      const orderCount = listOrdersResponse.json('ratings').length;
      console.log(`📋 Orders listed successfully: ${orderCount} orders found`);
    }
    
    // Record custom metrics
    transactionTime.add(orderPayload.stars * 100); // Simulate variable transaction time
  });
  
  sleep(1); // Simulate user review time
  
  // Group 4: Order Verification - Additional validation and business logic
  group('Order Verification', function () {
    // Verify order exists and has correct data
    const verifyResponse = http.get(
      `${BASE_URL}/api/ratings/${orderId}`,
      {
        headers: { 'Authorization': `Bearer ${authToken}` },
        tags: { name: 'verify_order', flow: 'verification', operation: 'GET' }
      }
    );
    
    const orderVerified = check(verifyResponse, {
      'verification: order still exists': (r) => r.status === 200,
      'verification: order data integrity': (r) => {
        const order = r.json();
        return order.id === orderId && order.stars >= 1 && order.stars <= 5;
      },
      'verification: order has timestamp': (r) => r.json('created_at') !== undefined,
    });
    
    if (orderVerified) {
      console.log(`✅ Order verification passed: ${orderId}`);
    }
    
    // Business logic: Count successful order only if all steps completed
    if (userRegistered && userAuthenticated && orderCreated && orderVerified) {
      successfulOrders.add(1);
      console.log(`🎯 Complete order flow successful for: ${USERNAME}`);
    }
  });
  
  sleep(0.5); // Brief pause before cleanup
  
  // Group 5: Cleanup - Delete the order (optional cleanup)
  group('Cleanup', function () {
    const deleteResponse = http.del(
      `${BASE_URL}/api/ratings/${orderId}`,
      null,
      {
        headers: { 'Authorization': `Bearer ${authToken}` },
        tags: { name: 'delete_order', flow: 'cleanup', operation: 'DELETE' }
      }
    );
    
    const orderDeleted = check(deleteResponse, {
      'order deletion status is 204': (r) => r.status === 204,
    });
    
    if (orderDeleted) {
      console.log(`🗑️ Order cleaned up successfully: ${orderId}`);
    } else {
      console.log(`⚠️ Order cleanup skipped or failed: ${deleteResponse.status}`);
    }
  });
  
  // Calculate and record total transaction time
  const transactionEnd = new Date();
  const totalTransactionTime = transactionEnd - transactionStart;
  transactionTime.add(totalTransactionTime);
  
  // Update active users gauge (decrement)
  activeUsers.add(-1);
  
  console.log(`⏱️ Total transaction time: ${totalTransactionTime}ms for user: ${USERNAME}`);
}

// Teardown function: Runs once after all VUs complete
export function teardown(data) {
  console.log('🏁 E-commerce Performance Test Complete!');
  console.log(`📊 Test started at: ${data.testStartTime}`);
  console.log(`📊 Test ended at: ${new Date().toISOString()}`);
}

/*
COMPREHENSIVE LEARNING SUMMARY:

🎯 END-TO-END FLOW DEMONSTRATED:
1. User Registration (POST) - Create new user account
2. Authentication (POST) - Login and get bearer token  
3. Order Creation (POST) - Create new order/rating
4. Order Retrieval (GET) - Fetch specific order by ID
5. Order Listing (GET) - Get all user orders
6. Order Verification (GET) - Validate order integrity
7. Order Cleanup (DELETE) - Remove test data

🏷️ TAGS IMPLEMENTATION:
- name: register, login, create_order, get_order, etc.
- flow: registration, authentication, order_management, etc.
- operation: POST, GET, DELETE

📊 CUSTOM METRICS (ALL 4 TYPES):
- Trend: transaction_time (tracks end-to-end timing)
- Counter: successful_orders (counts completed flows)  
- Rate: authentication_rate (login success percentage)
- Gauge: active_users (concurrent user tracking)

🏗️ GROUPS ORGANIZATION:
- User Registration: Account creation workflow
- Authentication: Login and token management
- Order Management: Core CRUD operations
- Order Verification: Data integrity checks
- Cleanup: Resource cleanup

🎚️ COMPREHENSIVE THRESHOLDS:
- Built-in metrics: Overall performance (http_req_duration, http_req_failed)
- Tagged metrics: Per-endpoint performance (login, create_order, etc.)
- Group metrics: Per-workflow performance (registration, authentication)
- Custom metrics: Business logic thresholds (transaction_time, successful_orders)

🔧 ADVANCED FEATURES:
- Bearer token authentication flow
- Error handling and early exit strategies
- Dynamic data generation (random users, orders)
- Business logic validation
- Comprehensive logging and debugging
- Setup/teardown lifecycle management

🎭 LOAD TESTING STAGES:
- Warm-up, ramp-up, peak load, scale-down, cool-down
- Realistic user simulation with thinking time
- Concurrent user monitoring

This script demonstrates ALL concepts learned:
✅ Tags (request-level filtering)
✅ Custom Metrics (all 4 types)
✅ Groups (workflow organization)
✅ Thresholds (comprehensive coverage)
✅ Authentication (Bearer token)
✅ CRUD Operations (POST, GET, DELETE)
✅ Error Handling
✅ Business Logic Validation
✅ End-to-End Flow Testing
*/
