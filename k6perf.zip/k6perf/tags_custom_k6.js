import http from 'k6/http';
import { check, sleep, group } from 'k6';
import { Counter, Trend, Rate } from 'k6/metrics';

// Custom Metrics - All three types
const apiResponseTime = new Trend('api_response_time');           // Trend: Track response times
const successfulRequests = new Counter('successful_requests');   // Counter: Count successful requests
const errorRate = new Rate('error_rate');                        // Rate: Calculate error percentage

// Configuration: Stages and Thresholds
export const options = {
  stages: [
    { duration: '10s', target: 2 },   // Ramp up to 2 VUs over 10 seconds
    { duration: '20s', target: 3 },   // Stay at 3 VUs for 20 seconds
    { duration: '10s', target: 0 },   // Ramp down to 0 VUs over 10 seconds
  ],
  
  // Thresholds: Combining built-in metrics (with tags) + custom metrics + groups
  thresholds: {
    // Built-in metrics - Overall performance
    'http_req_duration': ['p(95)<500'],                    // All requests combined < 500ms
    'http_req_failed': ['rate<0.1'],                       // Less than 10% request failures
    'checks': ['rate>0.9'],                                // More than 90% checks pass
    
    // Tagged built-in metrics - Per-endpoint performance
    'http_req_duration{name:homepage}': ['p(95)<300'],     // Homepage specific threshold
    'http_req_duration{name:contact}': ['p(95)<400'],      // Contact page specific threshold
    'http_req_duration{name:api}': ['avg<200'],            // API endpoint average < 200ms
    'http_req_duration{name:api-batch}': ['avg<150'],      // API batch endpoint average < 150ms
    
    // Group-based thresholds - Per-group performance
    'group_duration{group:::Page Tests}': ['avg<1000'],    // Page tests group average < 1s
    'group_duration{group:::API Tests}': ['avg<500'],      // API tests group average < 500ms
    'checks{group:::Page Tests}': ['rate>0.8'],            // Page tests checks > 80%
    'checks{group:::API Tests}': ['rate>0.95'],            // API tests checks > 95%
    
    // Custom metrics - Business logic thresholds  
    'api_response_time': ['p(95)<250'],                     // Custom response time tracking
    'successful_requests': ['count>5'],                    // At least 5 successful requests
    'error_rate': ['rate<0.05'],                           // Less than 5% error rate (stricter than built-in)
  },
};

// Main test function - runs for each virtual user
export default function () {
  let allChecksPassed = true;  // Track overall success for business logic
  
  // Group 1: Page Tests - Testing website pages
  group('Page Tests', function () {
    // Request 1: Homepage with tags
    const homepageResponse = http.get('https://test.k6.io/', {
      tags: { name: 'homepage', type: 'page' }  // Tag for filtering
    });
    
    const homepageChecks = check(homepageResponse, {
      'homepage status is 200': (r) => r.status === 200,
      'homepage contains k6.io': (r) => r.body.includes('k6.io'),
    });
    
    // Record to custom metrics
    apiResponseTime.add(homepageResponse.timings.duration);
    if (homepageResponse.status !== 200) {
      errorRate.add(1);  // Record error
      allChecksPassed = false;
    } else {
      errorRate.add(0);  // Record success
    }
    
    if (!homepageChecks) allChecksPassed = false;
    
    sleep(1);
    
    // Request 2: Contact page with tags
    const contactResponse = http.get('https://test.k6.io/contacts.php', {
      tags: { name: 'contact', type: 'page' }   // Tag for filtering
    });
    
    const contactChecks = check(contactResponse, {
      'contact status is 200': (r) => r.status === 200,
      'contact contains Contact': (r) => r.body.includes('Contact'),
    });
    
    // Record to custom metrics
    apiResponseTime.add(contactResponse.timings.duration);
    if (contactResponse.status !== 200) {
      errorRate.add(1);  // Record error
      allChecksPassed = false;
    } else {
      errorRate.add(0);  // Record success
    }
    
    if (!contactChecks) allChecksPassed = false;
  });
  
  sleep(1);
  
  // Group 2: API Tests - Testing API endpoints (MULTIPLE REQUESTS)
  group('API Tests', function () {
    // Request 3: API endpoint with tags
    const apiResponse = http.get('https://test.k6.io/my_messages.php', {
      tags: { name: 'api', type: 'api' }        // Tag for filtering
    });
    
    const apiChecks = check(apiResponse, {
      'api status is 200': (r) => r.status === 200,
    });
    
    // Record to custom metrics
    apiResponseTime.add(apiResponse.timings.duration);
    if (apiResponse.status !== 200) {
      errorRate.add(1);  // Record error
      allChecksPassed = false;
    } else {
      errorRate.add(0);  // Record success
    }
    
    if (!apiChecks) allChecksPassed = false;
    
    sleep(0.5);  // Small delay between API calls
    
    // Request 4: Another API endpoint (simulate API batch operations)
    const apiResponse2 = http.get('https://test.k6.io/flip_coin.php', {
      tags: { name: 'api-batch', type: 'api' }  // Tag for filtering
    });
    
    const apiChecks2 = check(apiResponse2, {
      'api batch status is 200': (r) => r.status === 200,
      'api batch has result': (r) => r.body.includes('result'),
    });
    
    // Record to custom metrics
    apiResponseTime.add(apiResponse2.timings.duration);
    if (apiResponse2.status !== 200) {
      errorRate.add(1);  // Record error
      allChecksPassed = false;
    } else {
      errorRate.add(0);  // Record success
    }
    
    if (!apiChecks2) allChecksPassed = false;
  });
  
  // Group 3: Business Logic - Custom validation and metrics
  group('Business Logic', function () {
    // Custom Counter Logic: Count as successful only when ALL checks in iteration pass
    if (allChecksPassed) {
      successfulRequests.add(1);  // Increment counter for completely successful iteration
    }
    
    // Additional business logic could go here:
    // - Data validation checks
    // - Performance calculations
    // - Custom reporting
    // - Integration validations
  });
  
  sleep(1);
}

/*
LEARNING NOTES:

1. TAGS vs CUSTOM METRICS vs GROUPS:
   - Tags: Filter built-in metrics by request type (homepage, contact, api)
   - Custom Metrics: Track business-specific logic and calculations
   - Groups: Organize test logic into logical sections with separate metrics

2. METRIC TYPES:
   - Trend (apiResponseTime): Tracks values over time (min, max, avg, percentiles)
   - Counter (successfulRequests): Counts events (total count)
   - Rate (errorRate): Calculates percentages (0-1 ratio)

3. OUTPUT DIFFERENCES:
   - Tagged metrics appear under built-in metric sections with tag filters
   - Custom metrics appear in separate "CUSTOM" section with your names
   - Group metrics appear in "GROUPS" section with group names and timings

4. WHEN TO USE WHICH:
   - Use TAGS when you want to filter existing k6 metrics by request type
   - Use CUSTOM METRICS when you need business logic or different metric types
   - Use GROUPS when you want to organize test logic and measure section performance
   - Use ALL THREE when you want comprehensive monitoring (like this example)

5. THRESHOLD EXAMPLES:
   - 'http_req_duration{name:homepage}': ['p(95)<300']     // Tagged threshold
   - 'api_response_time': ['p(95)<250']                    // Custom threshold
   - 'error_rate': ['rate<0.05']                           // Rate threshold
   - 'successful_requests': ['count>5']                    // Counter threshold
   - 'group_duration{group:::Page Tests}': ['avg<1000']    // Group threshold
   - 'checks{group:::API Tests}': ['rate>0.95']            // Group-specific checks

6. GROUPS BENEFITS:
   - Logical organization of test steps
   - Separate timing metrics for different test phases
   - Easier debugging and analysis
   - Ability to set thresholds per test section
   - Better reporting and visualization
*/
