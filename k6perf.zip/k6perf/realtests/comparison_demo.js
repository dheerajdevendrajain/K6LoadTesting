/*
 * DIRECT COMPARISON: SharedArray vs Direct JSON Loading
 * This file demonstrates the actual memory and performance differences
 */

// ==== SCENARIO 1: Direct JSON Loading (What e2e.js does) ====
// Each VU loads JSON independently - NO memory sharing
function directJsonApproach() {
    // This would be called by each VU - memory NOT shared
    const userData = JSON.parse(open('./users.json')); // Each VU loads this separately
    
    // Generate unique username
    const template = userData[0];
    const username = template.username + randomString(8) + "@test.com";
    
    console.log(`Direct approach - VU ${__VU}: ${username}`);
    return { username, password: template.password };
}

// ==== SCENARIO 2: SharedArray Approach (What e2e_opt.js does) ====
import { SharedArray } from 'k6/data';

// This is loaded ONCE and shared across ALL VUs - memory efficient
const userTemplate = new SharedArray('userTemplate', function () {
    return JSON.parse(open('./users.json'));
});

function sharedArrayApproach() {
    // All VUs access the same shared memory - NO duplicate loading
    const template = userTemplate[0];
    const username = template.username + randomString(8) + "@test.com";
    
    console.log(`SharedArray approach - VU ${__VU}: ${username}`);
    return { username, password: template.password };
}

// ==== MEMORY USAGE COMPARISON ====
/*
With 1000 VUs and a 10KB JSON file:

DIRECT APPROACH (e2e.js):
- Each VU loads JSON independently
- Memory usage: 1000 VUs × 10KB = 10MB
- File I/O: 1000 separate file reads
- CPU: 1000 separate JSON.parse() operations

SHAREDARRAY APPROACH (e2e_opt.js):
- JSON loaded once, shared across all VUs
- Memory usage: 1 × 10KB = 10KB
- File I/O: 1 file read total
- CPU: 1 JSON.parse() operation

SAVINGS: 99.9% memory reduction, 999x fewer file operations
*/

// ==== REAL-WORLD SCENARIOS WHERE SHAREDARRAY MATTERS ====

// Scenario A: Large user database (realistic for enterprise testing)
const largeUserData = new SharedArray('largeUsers', function () {
    // Imagine this is a 50MB JSON file with 100,000 user records
    return JSON.parse(open('./large_users.json'));
});
// Without SharedArray: 1000 VUs × 50MB = 50GB memory usage! 
// With SharedArray: 50MB total memory usage

// Scenario B: Complex configuration data
const testConfig = new SharedArray('config', function () {
    return JSON.parse(open('./test_config.json'));
});
// Product catalogs, API endpoints, test parameters, etc.

// Scenario C: Reference data (doesn't change during test)
const referenceData = new SharedArray('reference', function () {
    return {
        countries: JSON.parse(open('./countries.json')),
        products: JSON.parse(open('./products.json')),
        categories: JSON.parse(open('./categories.json'))
    };
});

function randomString(length, charset = '') {
    if (!charset) charset = 'abcdefghijklmnopqrstuvwxyz';
    let res = '';
    while (length--) res += charset[(Math.random() * charset.length) | 0];
    return res;
}

// ==== THE VERDICT FOR OUR CURRENT SETUP ====
/*
With our current users.json (just 1 template object, ~100 bytes):

DIRECT APPROACH:
- 1000 VUs × 100 bytes = 100KB total memory
- Impact: Negligible

SHAREDARRAY APPROACH:  
- 1 × 100 bytes = 100 bytes total memory
- Impact: Technically better, but difference is minimal

CONCLUSION:
- For tiny JSON files (< 1KB): SharedArray provides minimal benefit
- For large JSON files (> 10KB): SharedArray provides significant benefits
- For our current setup: SharedArray is technically correct but not practically necessary

The VALUE of SharedArray becomes apparent when:
1. JSON files are large (user databases, product catalogs)
2. You have many VUs (hundreds to thousands)
3. You're loading reference data that doesn't change
*/

export default function() {
    // Both approaches work identically for small data
    // Choice depends on your specific use case and data size
    
    // Current approach (SharedArray) - technically optimal
    const user1 = sharedArrayApproach();
    
    // Alternative approach (Direct) - works fine for small data
    const user2 = directJsonApproach();
    
    console.log('Both users created successfully');
}
