import { check, sleep, group } from 'k6';
import http from 'k6/http';
import { Counter, Rate } from 'k6/metrics';

const BASE_URL = 'https://quickpizza.grafana.com';

// Load test configurations directly
const configsObj = JSON.parse(open('./test-configs.json'));

// Load user template directly
const userTemplate = JSON.parse(open('./users.json'));

// Custom metrics
const authenticationRate = new Rate('authentication_rate');
const successfulOrders = new Counter('successful_orders');

// Utility function
function randomString(length, charset = '') {
  if (!charset) charset = 'abcdefghijklmnopqrstuvwxyz';
  let res = '';
  while (length--) res += charset[(Math.random() * charset.length) | 0];
  return res;
}

// 🎯 DYNAMIC TEST CONFIGURATION SELECTION
function getTestConfig() {
  // Priority order for selecting test type:
  // 1. Command line environment variable: -e TEST_TYPE=smoke
  // 2. Environment variable: export TEST_TYPE=load
  // 3. Default fallback: smoke
  
  const testType = __ENV.TEST_TYPE || 'smoke';
  const config = configsObj[testType];
  
  if (!config) {
    console.error(`❌ Test type '${testType}' not found in test-configs.json`);
    console.log(`Available test types: ${Object.keys(configsObj).join(', ')}`);
    throw new Error(`Invalid test type: ${testType}`);
  }
  
  console.log(`🚀 Running ${testType.toUpperCase()} test: ${config.description}`);
  console.log(`📊 Stages: ${JSON.stringify(config.stages)}`);
  
  return config;
}

// Get the configuration dynamically
const selectedConfig = getTestConfig();

// 🔧 EXPORT DYNAMIC OPTIONS
export const options = {
  stages: selectedConfig.stages,
  thresholds: selectedConfig.thresholds,
  
  // Add test metadata
  tags: {
    testType: __ENV.TEST_TYPE || 'smoke'
  },
  
  // 🌐 GRAFANA CLOUD CONFIGURATION
  cloud: {
    // Project ID from your Grafana Cloud account
    projectID: 3724054, // Replace with your actual project ID
    
    // Test name and notes
    name: `E2E Ecommerce Test - ${__ENV.TEST_TYPE || 'smoke'}`,
    note: `Automated e2e test for user registration, authentication, and order management. Test type: ${__ENV.TEST_TYPE || 'smoke'}`,
    
    // Load zones - distribute load from different geographic locations
    distribution: {
      'amazon:us:ashburn': { loadZone: 'amazon:us:ashburn', percent: 100 }
     // 'amazon:ie:dublin': { loadZone: 'amazon:ie:dublin', percent: 50 }
    }
  }
};

// Setup function with configuration info
export function setup() {
  const testType = __ENV.TEST_TYPE || 'smoke';
  const config = configsObj[testType];
  
  console.log('🏗️  TEST SETUP STARTED');
  console.log('='.repeat(50));
  console.log(`📋 Test Type: ${testType.toUpperCase()}`);
  console.log(`📝 Description: ${config.description}`);

  
  return {
    testStartTime: new Date().toISOString(),
    testType: testType,
    config: config,
    baseUrl: BASE_URL
  };
}



// Main test function
export default function (data) {
  // Generate unique username for each VU iteration
  const USERNAME = userTemplate[0].username + randomString(8) + "@ecommerutoce.test";
  const PASSWORD = userTemplate[0].password;
  

  let authToken = null;
  let orderId = null;
  let userRegistered = false;
  let userAuthenticated = false;
  let orderCreated = false;

  // User Registration
  group('User Registration', function () {
    const registerPayload = {
            username: USERNAME,
            password: PASSWORD
        };
        const params = {
            headers: { 'Content-Type': 'application/json' },
            tags: { name: 'register', flow: 'registration', operation: 'POST' }

        }

     // 🔍 DEBUG: Log the registration request
  console.log('🔍 DEBUG - Registration Request:');
  console.log(`   Username: ${USERNAME}`);
  console.log(`   Password: ${PASSWORD}`);
  console.log(`   Payload: ${JSON.stringify(registerPayload)}`);
  console.log(`   URL: ${BASE_URL}/api/users`);
  console.log(`   Headers: ${JSON.stringify(params.headers)}`);
  console.log(`   Tags: ${JSON.stringify(params.tags)}`);
    
 const regresponse = http.post(`${BASE_URL}/api/users`, JSON.stringify(registerPayload), params)
    
   userRegistered = check(regresponse, {
            "response code was 201": (regresponse) => regresponse.status == 201
        })
  
  console.log('🔍 DEBUG - Registration Response:');
  console.log(`   Status: ${regresponse.status}`);
  console.log(`   Status Text: ${regresponse.status_text}`);
  console.log(`   Body: ${regresponse.body || 'EMPTY BODY'}`);
  console.log(`   Body Type: ${typeof regresponse.body}`);
  console.log(`   Body Length: ${regresponse.body ? regresponse.body.length : 0}`);
  console.log(`   Headers: ${JSON.stringify(regresponse.headers)}`);
  console.log(`   URL: ${regresponse.url}`);
  console.log(`   Request Duration: ${regresponse.timings.duration}ms`);
    
    if (!userRegistered) {
      console.error(`❌ User registration failed: ${regresponse.status} - ${regresponse.body}`);
      authenticationRate.add(0);
      return;
    }
    
    authenticationRate.add(1);
  });

  sleep(2);

  // Authentication
  group('Authentication', function () {
    const loginPayload = {
      username: USERNAME,
      password: PASSWORD
    };
    console.log('🔍 DEBUG - Authentication Request:');
  console.log(`   Username: ${USERNAME}`);
  console.log(`   Password: ${PASSWORD}`);
  console.log(`   Payload: ${JSON.stringify(loginPayload)}`);
  console.log(`   URL: ${BASE_URL}/api/users/token/login`);
    const loginResponse = http.post(
      `${BASE_URL}/api/users/token/login`,
      JSON.stringify(loginPayload),
      {
        headers: { 'Content-Type': 'application/json' },
        tags: { 
          name: 'login', 
          flow: 'authentication', 
          operation: 'POST',
          testType: data.testType
        }
      }
    );

    userAuthenticated = check(loginResponse, {
      'login status is 200': (r) => r.status === 200,
      'login response has body': (r) => r.body !== null && r.body !== '',
      'login response contains token': (r) => {
        try {
          return r.body && r.json('token') !== undefined;
        } catch (e) {
          return false;
        }
      },
      'token is valid string': (r) => {
        try {
          return r.body && typeof r.json('token') === 'string' && r.json('token').length > 0;
        } catch (e) {
          return false;
        }
      },
    });

    if (userAuthenticated && loginResponse.status === 200 && loginResponse.body) {
      try {
        authToken = loginResponse.json('token');
        authenticationRate.add(1);
        if (__ITER === 0) console.log(`🔐 User authenticated: ${USERNAME}`);
      } catch (e) {
        authenticationRate.add(0);
        console.error(`❌ Authentication failed - JSON parse error: ${e.message}`);
        return;
      }
    } else {
      authenticationRate.add(0);
      console.error(`❌ Authentication failed: Status ${loginResponse.status} - Body: ${loginResponse.body || 'empty'}`);
      return;
    }
  });

  sleep(1);

  // Order Management
  group('Order Management', function () {
    const authHeaders = {
      headers: {
        'Authorization': `Bearer ${authToken}`,
        'Content-Type': 'application/json'
      }
    };

    // Create order
    const orderPayload = {
      pizza_id: Math.floor(Math.random() * 5) + 1,
      stars: Math.floor(Math.random() * 5) + 1
    };

    const createOrderResponse = http.post(
      `${BASE_URL}/api/ratings`,
      JSON.stringify(orderPayload),
      {
        ...authHeaders,
        tags: { 
          name: 'create_order', 
          flow: 'order_management', 
          operation: 'POST',
          testType: data.testType
        }
      }
    );

    orderCreated = check(createOrderResponse, {
      'order creation status is 201': (r) => r.status === 201,
      'order creation response contains ID': (r) => r.json('id') !== undefined,
      'order creation stars match': (r) => r.json('stars') === orderPayload.stars,
      'order creation pizza_id match': (r) => r.json('pizza_id') === orderPayload.pizza_id,
    });

    if (orderCreated) {
      orderId = createOrderResponse.json('id');
      if (__ITER === 0) console.log(`📦 Order created: ${orderId}`);
    } else {
      console.error(`❌ Order creation failed: ${createOrderResponse.status} - ${createOrderResponse.body}`);
      return;
    }

    sleep(0.5);

    // Get order
    const getOrderResponse = http.get(
      `${BASE_URL}/api/ratings/${orderId}`,
      {
        ...authHeaders,
        tags: { 
          name: 'get_order', 
          flow: 'order_management', 
          operation: 'GET',
          testType: data.testType
        }
      }
    );

    const orderRetrieved = check(getOrderResponse, {
      'order retrieval status is 200': (r) => r.status === 200,
      'retrieved order ID matches': (r) => r.json('id') === orderId,
      'retrieved order has correct stars': (r) => r.json('stars') === orderPayload.stars,
      'retrieved order has correct pizza_id': (r) => r.json('pizza_id') === orderPayload.pizza_id,
    });

    if (orderRetrieved) {
      if (__ITER === 0) console.log(`✅ Order retrieved: ${orderId}`);
    }

    // Track successful complete flows
    if (userRegistered && userAuthenticated && orderCreated && orderRetrieved) {
      successfulOrders.add(1);
      if (__ITER === 0) console.log(`🎯 Complete flow successful: ${USERNAME}`);
    }
  });
}

// Teardown function
export function teardown(data) {
  console.log('🏁 TEST COMPLETED');
  console.log('='.repeat(50));
  console.log(`📋 Test Type: ${data.testType.toUpperCase()}`);
  console.log(`📝 Description: ${data.config.description}`);
  console.log(`📊 Started: ${data.testStartTime}`);
  console.log(`📊 Ended: ${new Date().toISOString()}`);
  console.log(`🌍 Environment: ${__ENV.ENVIRONMENT || 'test'}`);
  console.log(`📦 Version: ${__ENV.VERSION || 'v1.0'}`);
  console.log('='.repeat(50));
}

/*
🚀 DYNAMIC TEST CONFIGURATION USAGE:

💡 BASIC USAGE:
k6 run e2e_configurable.js                    # Runs smoke test (default)
k6 run e2e_configurable.js -e TEST_TYPE=load  # Runs load test
k6 run e2e_configurable.js -e TEST_TYPE=stress # Runs stress test

🎯 ADVANCED USAGE:
k6 run e2e_configurable.js -e TEST_TYPE=load -e ENVIRONMENT=staging -e VERSION=v2.1
k6 run e2e_configurable.js -e TEST_TYPE=soak -e ENVIRONMENT=prod

📊 AVAILABLE TEST TYPES:
- smoke: Quick verification (1 VU, 90s)
- load: Normal expected load (10-20 VUs, 19m)
- stress: High load testing (10-100 VUs, 31m)
- spike: Sudden traffic bursts (10-50 VUs, 8m)
- soak: Extended duration (10 VUs, 3h+)

🔧 CONFIGURATION BENEFITS:
- Centralized test scenarios
- Runtime test type selection
- Consistent thresholds per test type
- Easy team collaboration
- CI/CD integration friendly
- Environment-specific settings

📈 CI/CD INTEGRATION:
# In your CI/CD pipeline:
- stage: smoke
  k6 run e2e_configurable.js -e TEST_TYPE=smoke
- stage: load
  k6 run e2e_configurable.js -e TEST_TYPE=load -e ENVIRONMENT=staging
- stage: stress
  k6 run e2e_configurable.js -e TEST_TYPE=stress -e ENVIRONMENT=prod
*/