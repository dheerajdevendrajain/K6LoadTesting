import { check,sleep,group } from 'k6';
import http from 'k6/http';
import { Counter, Trend, Rate, Gauge } from 'k6/metrics';

const BASE_URL = 'https://quickpizza.grafana.com';
const USERNAME = `user_${randomString(8)}@eeroce.test`;
const PASSWORD = 'securepassword123';
const authenticationRate = new Rate('authentication_rate'); 
const successfulOrders = new Counter('successful_orders');    

function randomString(length) {
  // More characters, same length
  const charset = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';

  for (let i = 0; i < length; i++) {
    const randomIndex = Math.floor(Math.random() * charset.length);
    result += charset[randomIndex];
  }

  return result;
}

export const options = {
    stages: [
        { duration: '5s', target: 2 },   // Warm-up: 5 users
       // { duration: '10s', target: 10 },   // Ramp up: 10 users // Peak load: 15 users
        { duration: '5s', target: 2 },   // Scale down: 10 users  
        { duration: '5s', target: 0 },   // Cool down: 0 users
    ],

    thresholds: {
        'http_req_duration' : ['p(90)<3700'],
        'checks': ['rate>0.90'],
        'iteration_duration': ['p(95)<14000'], 
        'authentication_rate': ['rate>0.98'], 
        'http_req_duration{name:create_order}': ['p(95)<1500'], 
        'group_duration{group:::Order Management}': ['avg<1000'],
        'successful_orders': ['count>5'],   
             // Order creation < 1.5s


    }
}

export default function () {
let authToken = null;
  let orderId = null;
  let userRegistered = false;
  let userAuthenticated = false;
  let orderCreated = false;
    group('User Registration', function () {
        const url = 'https://quickpizza.grafana.com'
        const registerPayload = {
            username: USERNAME,
            password: PASSWORD
        };
        const params = {
            headers: { 'Content-Type': 'application/json' },
            tags: { name: 'register', flow: 'registration', operation: 'POST' }

        }
  //         console.log('🔍 DEBUG - Registration Request:');
  // console.log(`   Usernaconsme: ${USERNAME}`);e2e
  // console.log(`   Password: ${PASSWORD}`);
  // console.log(`   Payload: ${JSON.stringify(registerPayload)}`);
  // console.log(`   URL: ${BASE_URL}/api/users`);
  // console.log(`   Headers: ${JSON.stringify(params.headers)}`);
  // console.log(`   Tags: ${JSON.stringify(params.tags)}`);
        const regresponse = http.post(`${BASE_URL}/api/users`, JSON.stringify(registerPayload), params)

        
        userRegistered = check(regresponse, {
            "response code was 201": (regresponse) => regresponse.status == 201
        })
        if (!userRegistered) {
            console.error(`❌ User registration failed: ${regresponse.status} - ${regresponse.body}`);
            authenticationRate.add(0);
            return; // Exit early if registration fails
        }
        authenticationRate.add(1); // Record successful registration
    })
     sleep(1);
     group('authentication',function()
    {
     const loginPayload = {
      username: USERNAME,
      password: PASSWORD
    };
    const loginResponse = http.post(
          `${BASE_URL}/api/users/token/login`,
          JSON.stringify(loginPayload),
          {
            headers: { 'Content-Type': 'application/json' },
            tags: { name: 'login', flow: 'authentication', operation: 'POST' }
          }
        );

   userAuthenticated = check(loginResponse, {
      'login status is 200': (r) => r.status === 200,
      'login response contains token': (r) => r.json('token') !== undefined,
      'token is valid string': (r) => typeof r.json('token') === 'string' && r.json('token').length > 0,
    });

    if (userAuthenticated) {
      authToken = loginResponse.json('token');
      authenticationRate.add(1); // Record successful authentication
      console.log(`🔐 User authenticated successfully: ${USERNAME}`);
    } else {
      authenticationRate.add(0); // Record failed authentication
      console.error(`❌ Authentication failed: ${loginResponse.status} - ${loginResponse.body}`);
      return; // Exit early if authentication fails
    }


    })
    sleep(1); 



   group('Order Management', function () {
       // Headers for authenticated requests
       const authHeaders = {
         headers: {
           'Authorization': `Bearer ${authToken}`,
           'Content-Type': 'application/json'
         }
       };
       
       // Step 1: Create a new order (POST)
      //  const orderPayload = {
      //    pizza_id: Math.floor(Math.random() * 5) + 1, // Random pizza ID (1-5)
      //    stars: Math.floor(Math.random() * 5) + 1    // Random rating (1-5 stars)
      //  };

     const orderPayload = {
       maxCaloriesPerSlice: 1000,
       mustBeVegetarian: true,
       excludedIngredients: [],
       excludedTools: ['Pizza cutter'],
       maxNumberOfToppings: 5,
       minNumberOfToppings: 2,
       customName: 'ssd'
     };
       
       const createOrderResponse = http.post(
         `${BASE_URL}/api/pizza`,
         JSON.stringify(orderPayload),
         {
           ...authHeaders,
           tags: { name: 'create_order', flow: 'order_management', operation: 'POST' }
         }
       );
       
       orderCreated = check(createOrderResponse, {
         'order creation status is 201': (r) => r.status === 200,
         'order creation response contains ID': (r) => r.json('pizza.id') !== undefined,
         'order creation stars match': (r) => r.json('pizza.name') === orderPayload.customName,
       });
       
       if (orderCreated) {
         orderId = createOrderResponse.json('pizza.id');
         console.log(`📦 Order created successfully: ${orderId}`);
       } else {
         console.error(`❌ Order creation failed: ${createOrderResponse.status} - ${createOrderResponse.body}`);
         return; // Exit early if order creation fails
       }
       
       sleep(0.5); // Brief pause between operations
       
       // Step 2: Retrieve the specific order (GET)
       const getOrderResponse = http.get(
         `${BASE_URL}/api/pizza/${orderId}`,
         {
           ...authHeaders,
           tags: { name: 'get_order', flow: 'order_management', operation: 'GET' }
         }
       );
       
       const orderRetrieved = check(getOrderResponse, {
         'order retrieval status is 200': (r) => r.status === 200,
         'retrieved order ID matches': (r) => r.json('id') === orderId,
         'retrieved order has correct pizza_id': (r) => r.json('name') === orderPayload.customName,
       });
       
       if (orderRetrieved) {
         console.log(`✅ Order retrieved successfully: ${orderId}`);
       } 

       if (userRegistered && userAuthenticated && orderCreated && orderRetrieved) {
      successfulOrders.add(1);
      console.log(`🎯 Complete order flow successful for: ${USERNAME}`);
    }
});

}