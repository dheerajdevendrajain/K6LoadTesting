import { check,sleep,group } from 'k6';
import http from 'k6/http';
import { Counter, Trend, Rate, Gauge } from 'k6/metrics';
import { SharedArray } from 'k6/data';

const BASE_URL = 'https://quickpizza.grafana.com';

// SharedArray to load user template once and share across all VUs
const userTemplate = new SharedArray('userTemplate', function () {
  return JSON.parse(open('./users.json'));
});

const authenticationRate = new Rate('authentication_rate'); 
const successfulOrders = new Counter('successful_orders');    

function randomString(length, charset = '') {
  if (!charset) charset = 'abcdefghijklmnopqrstuvwxyz';
  let res = '';
  while (length--) res += charset[(Math.random() * charset.length) | 0];
  return res;
}

export const options = {
    stages: [
        { duration: '5s', target: 5 },   // Warm-up: 5 users
        { duration: '10s', target: 10 },   // Ramp up: 10 users // Peak load: 15 users
        { duration: '5s', target: 10 },   // Scale down: 10 users  
        { duration: '10s', target: 0 },   // Cool down: 0 users
    ],

    thresholds: {
        'http_req_duration' : ['p(90)<3700'],
        'checks': ['rate>0.90'],
        'iteration_duration': ['p(95)<14000'], 
        'authentication_rate': ['rate>0.98'], 
        'http_req_duration{name:create_order}': ['p(95)<1500'], 
        'group_duration{group:::Order Management}': ['avg<1000'],
        'successful_orders': ['count>5'],   
             // Order creation < 1.5s


    }
}

// Setup function: Pre-test validation and configuration
export function setup() {
  console.log('🚀 Starting E-commerce Performance Test Setup...');
  console.log('=====================================');
  
  // Step 1: Verify API availability by checking homepage
  console.log('📡 Verifying API availability...');
  const apiCheck = http.get(`${BASE_URL}/`);
  
  if (apiCheck.status === 0) {
    console.error('❌ API is unreachable. Aborting test.');
    throw new Error('API endpoint is not available');
  }
  console.log(`✅ API is reachable (Status: ${apiCheck.status})`);
  
  // Step 2: Verify critical endpoints
  console.log('🔍 Checking critical endpoints...');
  const endpoints = {
    users: http.get(`${BASE_URL}/api/users`),
    pizzas: http.get(`${BASE_URL}/api/pizzas`)
  };
  
  console.log(`   - /api/users: ${endpoints.users.status}`);
  console.log(`   - /api/pizzas: ${endpoints.pizzas.status}`);
  
  const testConfig = {
    testStartTime: new Date().toISOString(),
    baseUrl: BASE_URL,
    apiStatus: apiCheck.status,
    endpointsChecked: true,
  };
  
  console.log('=====================================');
  console.log('✅ Setup completed successfully!');
  console.log('🏁 Starting load test execution...\n');
  
  return testConfig;
}

export default function (data) {
  // Generate unique username for each VU iteration - Simple and dynamic!
  const template = userTemplate[0];
  const USERNAME = template.username + randomString(8) + "@ecommerce.test";
  const PASSWORD = template.password;
  
  console.log(`🔄 VU ${__VU} using randomly generated user: ${USERNAME}`);
  
  let authToken = null;
  let orderId = null;
  let userRegistered = false;
  let userAuthenticated = false;
  let orderCreated = false;
    group('User Registration', function () {
        // Use SharedArray user data instead of generating random users
        const registerPayload = {
            username: USERNAME,
            password: PASSWORD
        };
        const params = {
            headers: { 'Content-Type': 'application/json' },
            tags: { name: 'register', flow: 'registration', operation: 'POST' }

        }
        const regresponse = http.post(`${BASE_URL}/api/users`, JSON.stringify(registerPayload), params)
        userRegistered = check(regresponse, {
            "response code was 201": (regresponse) => regresponse.status == 201
        })
        if (!userRegistered) {
            console.error(`❌ User registration failed: ${regresponse.status} - ${regresponse.body}`);
            authenticationRate.add(0);
            return; // Exit early if registration fails
        }
        authenticationRate.add(1); // Record successful registration
        console.log(`✅ User registered successfully: ${USERNAME}`);
    })
     sleep(1);
     group('authentication',function()
    {
     // Use SharedArray user data for login
     const loginPayload = {
      username: USERNAME,
      password: PASSWORD
    };
    const loginResponse = http.post(
          `${BASE_URL}/api/users/token/login`,
          JSON.stringify(loginPayload),
          {
            headers: { 'Content-Type': 'application/json' },
            tags: { name: 'login', flow: 'authentication', operation: 'POST' }
          }
        );

   userAuthenticated = check(loginResponse, {
      'login status is 200': (r) => r.status === 200,
      'login response contains token': (r) => r.json('token') !== undefined,
      'token is valid string': (r) => typeof r.json('token') === 'string' && r.json('token').length > 0,
    });

    if (userAuthenticated) {
      authToken = loginResponse.json('token');
      authenticationRate.add(1); // Record successful authentication
      console.log(`🔐 User authenticated successfully: ${USERNAME}`);
    } else {
      authenticationRate.add(0); // Record failed authentication
      console.error(`❌ Authentication failed: ${loginResponse.status} - ${loginResponse.body}`);
      return; // Exit early if authentication fails
    }


    })
    sleep(1); 



   group('Order Management', function () {
       // Headers for authenticated requests
       const authHeaders = {
         headers: {
           'Authorization': `Bearer ${authToken}`,
           'Content-Type': 'application/json'
         }
       };
       
       // Step 1: Create a new order (POST)
       const orderPayload = {
         pizza_id: Math.floor(Math.random() * 5) + 1, // Random pizza ID (1-5)
         stars: Math.floor(Math.random() * 5) + 1    // Random rating (1-5 stars)
       };
       
       const createOrderResponse = http.post(
         `${BASE_URL}/api/ratings`,
         JSON.stringify(orderPayload),
         {
           ...authHeaders,
           tags: { name: 'create_order', flow: 'order_management', operation: 'POST' }
         }
       );
       
       orderCreated = check(createOrderResponse, {
         'order creation status is 201': (r) => r.status === 201,
         'order creation response contains ID': (r) => r.json('id') !== undefined,
         'order creation stars match': (r) => r.json('stars') === orderPayload.stars,
         'order creation pizza_id match': (r) => r.json('pizza_id') === orderPayload.pizza_id,
       });
       
       if (orderCreated) {
         orderId = createOrderResponse.json('id');
         console.log(`📦 Order created successfully: ${orderId}`);
       } else {
         console.error(`❌ Order creation failed: ${createOrderResponse.status} - ${createOrderResponse.body}`);
         return; // Exit early if order creation fails
       }
       
       sleep(0.5); // Brief pause between operations
       
       // Step 2: Retrieve the specific order (GET)
       const getOrderResponse = http.get(
         `${BASE_URL}/api/ratings/${orderId}`,
         {
           ...authHeaders,
           tags: { name: 'get_order', flow: 'order_management', operation: 'GET' }
         }
       );
       
       const orderRetrieved = check(getOrderResponse, {
         'order retrieval status is 200': (r) => r.status === 200,
         'retrieved order ID matches': (r) => r.json('id') === orderId,
         'retrieved order has correct stars': (r) => r.json('stars') === orderPayload.stars,
         'retrieved order has correct pizza_id': (r) => r.json('pizza_id') === orderPayload.pizza_id,
       });
       
       if (orderRetrieved) {
         console.log(`✅ Order retrieved successfully: ${orderId}`);
       } 

       if (userRegistered && userAuthenticated && orderCreated && orderRetrieved) {
      successfulOrders.add(1);
      console.log(`🎯 Complete order flow successful for: ${USERNAME}`);
    }
});

}

// Teardown function: Post-test cleanup and reporting
export function teardown(data) {
  console.log('\n🏁 E-commerce Performance Test Complete!');
  console.log('=====================================');
  
  // Calculate test duration
  const startTime = new Date(data.testStartTime);
  const endTime = new Date();
  const durationSec = ((endTime - startTime) / 1000).toFixed(2);
  
  console.log(`📊 Test started: ${data.testStartTime}`);
  console.log(`📊 Test ended: ${endTime.toISOString()}`);
  console.log(`⏱️  Duration: ${durationSec}s`);
  console.log(`🌐 Base URL: ${data.baseUrl}`);
  console.log(`✅ API Status: ${data.apiStatus}`);
  
  // Post-test verification
  console.log('\n🔍 Post-test API check...');
  const postCheck = http.get(`${data.baseUrl}/`);
  console.log(`   API still responsive: ${postCheck.status === 200 ? '✅ Yes' : '⚠️  No'}`);
  
  console.log('\n📈 View detailed metrics above');
  console.log('=====================================');
  console.log('✅ Teardown completed!\n');
}

/*
SIMPLIFIED DYNAMIC USER GENERATION:

🚀 ULTIMATE SIMPLICITY:
- Single user template in JSON: {"username": "user_", "password": "..."}
- Each VU generates unique username on-the-fly with randomString(8)
- No pre-calculation, no arrays, no complex setup logic
- Pure simplicity and flexibility

🔄 ON-THE-FLY GENERATION:
- Every VU iteration: "user_" + randomString(8) + "@ecommerce.test"
- Example: user_abc12def@ecommerce.test, user_xyz34ghi@ecommerce.test
- Guaranteed unique every time (no cycling needed)

⚡ PERFORMANCE BENEFITS:
- Minimal JSON file (just prefix + password)
- Minimal setup function
- No memory overhead for user arrays
- No max user calculations needed
- SharedArray only for template (tiny footprint)

📊 DYNAMIC SCALING:
- Works with any number of VUs automatically
- No configuration needed for different test scales
- Each iteration gets fresh unique username
- Perfect for stress testing with unknown VU counts

🎯 KISS PRINCIPLE PERFECTED:
- Absolutely minimal complexity
- Easy to understand and maintain
- No edge cases with user cycling
- Just works™ for any scenario
*/