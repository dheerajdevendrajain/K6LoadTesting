import http from 'k6/http';
import { open, check } from 'k6';
import { htmlReport } from "https://raw.githubusercontent.com/benc-uk/k6-reporter/main/dist/bundle.js";

// Define test options
export const options = {
  stages: [
    { duration: '5s', target: 2 },   // Ramp up to 2 VUs over 5 seconds
    { duration: '10s', target: 5 },  // Stay at 5 VUs for 10 seconds
    { duration: '5s', target: 0 },   // Ramp down to 0 VUs over 5 seconds
  ],
  // Add a threshold to fail the test if checks don't pass consistently
  thresholds: {
    'checks': ['rate>0.99'], // 99% of checks must pass
    'http_req_failed': ['rate<0.01'], // less than 1% of HTTP requests should fail
  },
  // Debugging options
  // --http-debug="full" will log full request/response bodies, useful for debugging
  // If you run with k6 run --http-debug="full" your_script.js, you'll see a lot of output
};

export default function () {
  // Define the path to your test file (ensure it exists and k6 has read permissions)
  // For cross-platform compatibility, consider using __ENV.FILE_PATH
  const filePath = '/Users/rahulshetty/downloads/puneevent.jpg'; 

  let binFile;

    binFile = open(filePath, 'b'); // 'b' for binary mode
  const formData = {
    file: http.file(binFile, 'puneevent.jpg', 'image/jpeg'), // data, filename, content_type
    description: 'A test image uploaded from k6',

  const headers = {
    // 'Content-Type': 'multipart/form-data; boundary=xxxxxx' - k6 handles this.
  };
  const response = http.post('https://httpbin.org/post', formData, { headers: headers });

  console.log(`HTTPBin Response Status: ${response.status}`);

  

}




    // Example 2: JSONPlaceholder (Mock API)
    // const textFile = open('/path/to/document.txt', 'b');
    // const jsonPlaceholderData = {
    //     file: http.file(textFile, 'document.txt', 'text/plain'),
    //     title: 'Test Document',
    //     userId: 1
    // };
    
    // const response2 = http.post('https://jsonplaceholder.typicode.com/posts', jsonPlaceholderData);
    // console.log('JSONPlaceholder Response:', response2.status);
    
    // Example 3: ImgBB Image Upload (Real image hosting service)
    // Note: You need to get a free API key from https://api.imgbb.com/
    // const imageFile = open('/path/to/image.jpg', 'b');
    // const imgbbData = {
    //     image: http.file(imageFile, 'upload.jpg', 'image/jpeg'),
    //     name: 'k6-test-upload'
    // };
    
    // const response3 = http.post('https://api.imgbb.com/1/upload?key=YOUR_API_KEY', imgbbData);
    // console.log('ImgBB Response:', response3.status);
    
    // Example 4: Postman Echo (Real testing endpoint)
    // const docFile = open('/path/to/file.pdf', 'b');
    // const postmanData = {
    //     file: http.file(docFile, 'test.pdf', 'application/pdf'),
    //     metadata: 'Test file for k6'
    // };
    
    // const response4 = http.post('https://postman-echo.com/post', postmanData);
    // console.log('Postman Echo Response:', response4.status);
