import http from 'k6/http';
import { check, sleep } from 'k6';
import { Trend, Counter, Rate } from 'k6/metrics';

// Custom Metrics - Track each request type separately
const homepageResponseTime = new Trend('homepage_response_time');
const contactResponseTime = new Trend('contact_response_time'); 
const aboutResponseTime = new Trend('about_response_time');
const successfulRequests = new Counter('successful_requests');
const errorRate = new Rate('error_rate');

// Configuration: Simple stages for demonstration
export const options = {
  stages: [
    { duration: '10s', target: 2 },   // Ramp up to 2 VUs over 10 seconds
    { duration: '20s', target: 3 },   // Stay at 3 VUs for 20 seconds
    { duration: '10s', target: 0 },   // Ramp down to 0 VUs over 10 seconds
  ],
  
  // Thresholds: Notice how we can set different thresholds for our custom metrics
  thresholds: {
    'http_req_duration': ['p(95)<500'],                    // All requests combined (built-in)
    'homepage_response_time': ['p(95)<300'],               // Only homepage requests (custom)
    'contact_response_time': ['p(95)<400'],                // Only contact page requests (custom)
    'about_response_time': ['p(95)<350'],                  // Only about page requests (custom)
    'successful_requests': ['count>10'],                   // At least 10 successful requests
    'error_rate': ['rate<0.1'],                            // Less than 10% error rate
    'http_req_failed': ['rate<0.1'],
    'checks': ['rate>0.9'],
  },
};

// Main test function - runs for each virtual user
export default function () {
  // Request 1: Homepage with custom metric tracking
  const homepageResponse = http.get('https://test.k6.io/');
  
  const homepageChecks = check(homepageResponse, {
    'homepage status is 200': (r) => r.status === 200,
    'homepage contains k6.io': (r) => r.body.includes('k6.io'),
  });
  
  // Record custom metrics for homepage
  homepageResponseTime.add(homepageResponse.timings.duration);
  if (homepageResponse.status !== 200) {
    errorRate.add(1);  // Record error
  } else {
    errorRate.add(0);  // Record success
  }
  
  sleep(1); // Simulate user think time
  
  // Request 2: Contact page with custom metric tracking
  const contactResponse = http.get('https://test.k6.io/contacts.php');
  
  const contactChecks = check(contactResponse, {
    'contact status is 200': (r) => r.status === 200,
    'contact contains Contact': (r) => r.body.includes('Contact'),
  });
  
  // Record custom metrics for contact page
  contactResponseTime.add(contactResponse.timings.duration);
  if (contactResponse.status !== 200) {
    errorRate.add(1);  // Record error
  } else {
    errorRate.add(0);  // Record success
  }
  
  sleep(1); // Simulate user think time
  
  // Request 3: About page with custom metric tracking
  const aboutResponse = http.get('https://test.k6.io/my_messages.php');
  
  const aboutChecks = check(aboutResponse, {
    'about status is 200': (r) => r.status === 200,
  });
  
  // Record custom metrics for about page
  aboutResponseTime.add(aboutResponse.timings.duration);
  if (aboutResponse.status !== 200) {
    errorRate.add(1);  // Record error
  } else {
    errorRate.add(0);  // Record success
  }
  
  // Count successful requests (when all checks pass)
  if (homepageChecks && contactChecks && aboutChecks) {
    successfulRequests.add(1);
  }
  
  sleep(1); // Simulate user think time between iterations
}
